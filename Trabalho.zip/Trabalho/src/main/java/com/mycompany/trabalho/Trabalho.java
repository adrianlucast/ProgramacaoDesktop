/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho;

import com.mycompany.trabalho.frames.FrameLogin;

/**
 *
 * @author zfins
 */
public class Trabalho {

    public static void main(String[] args) {
        new FrameLogin().setVisible(true);
    }
}
